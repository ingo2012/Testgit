/*
 * EpromType.java
 * @author monitor
 * Created on 09.03.2010, 20:58:24
 *
 * Defines a Eprom

---------------------------------------------------------------------------------
-----------------------       C V S - I n f o    --------------------------------
---------------------------------------------------------------------------------
 Info : $Id: EpromType.java,v 1.5 2010/05/22 16:18:17 cvs Exp $
 Log  : $Log: EpromType.java,v $
 Log  : Revision 1.5  2010/05/22 16:18:17  cvs
 Log  : Stand 22.05.10
 Log  :
 Log  : Revision 1.4  2010/05/21 16:23:10  cvs
 Log  : Stand 20.05.10
 Log  :
 Log  : Revision 1.3  2010/05/13 11:56:02  cvs
 Log  : Images hinzu
 Log  :

---------------------------------------------------------------------------------
-----------------------       C V S - I n f o    --------------------------------
---------------------------------------------------------------------------------
 *
 */

package com.gui;


/**
 * Define a Eprom with Size, Command ....
 * @author monitor
 */
public class EpromType {

    String Type   = null;
    Integer Size  = 0;
    String Cmd    = null;
    Integer Delay = 0;


    public EpromType(String Type, int Size,String Cmd,int Delay) {
        this.Type  = Type;
        this.Size  = Size;
        this.Cmd   = Cmd;
        this.Delay = Delay;
    }

}
